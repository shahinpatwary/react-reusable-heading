import './App.css';
import ReusableHeading from './components/ReusableHeading';

function App() {

  return (
    <>
     
        
      <ReusableHeading
        tagline="About Us"
        SectionTitle="Almost every major <span>economy around</span> the global"
        SectionIntro="SMEs are the backbone of almost every major economy around the globe! SMEs are the backbone of almost every major economy around the globe!"
      />
      
    </>
  )
}

export default App
